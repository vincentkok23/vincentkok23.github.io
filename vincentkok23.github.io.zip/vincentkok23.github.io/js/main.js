function BYE(){
    document.getElementById("BYE").externalHtml = "HEY"
}